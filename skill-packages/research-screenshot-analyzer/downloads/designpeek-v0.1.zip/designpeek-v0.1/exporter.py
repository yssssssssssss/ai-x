"""导出项目分析结果为自包含 HTML(截图内嵌 base64,可直接发同事离线查看)。"""

import base64
import html
import io
import os
import re

from PIL import Image

from config import SCREENSHOTS_DIR

# 缩略图内嵌参数:控制单文件体积。420px 宽足够看清移动端布局。
THUMB_WIDTH = 420
THUMB_QUALITY = 72

# App 名 → 图标文件(与前端 APP_ICON_IMG 对应)
APP_ICON_FILES = {
    "微信": "com.tencent.mm.png",
    "抖音": "com.ss.android.ugc.aweme.png",
    "小红书": "com.xingin.xhs.png",
    "微博": "com.sina.weibo.png",
    "淘宝": "com.taobao.taobao.png",
    "京东": "com.jingdong.app.mall.png",
    "美团": "com.sankuai.meituan.png",
    "支付宝": "com.eg.android.AlipayGphone.png",
    "快手": "com.kuaishou.png",
    "B站": "tv.danmaku.bili.png",
    "哔哩哔哩": "tv.danmaku.bili.png",
    "拼多多": "com.xunmeng.pinduoduo.png",
    "钉钉": "com.alibaba.android.rimet.png",
    "网易云音乐": "com.netease.cloudmusic.png",
    "闲鱼": "com.taobao.idlefish.png",
    "芒果TV": "com.hunantv.imgo.activity.png",
    "携程旅行": "com.ctrip.android.viewhome.png",
    "大众点评": "com.dianping.v1.png",
    "IKEA宜家家居": "com.ingka.ikea.app.cn.prod.png",
    "懂车帝": "com.ss.ios.auto.png",
    "蔚来": "com.do1.WeiLaiApp.png",
    "小鹏汽车": "com.xiaopeng.XiaoPengQiChe.png",
    "极氪": "com.zeekrlife.mobile.png",
    "莲花跑车": "com.lotus.lotusCustomer.png",
    "汽车之家": "com.autohome.png",
    "小米汽车": "com.mi.car.mobile.png",
}

APP_EMOJI = {
    "微信": "💬", "抖音": "🎵", "小红书": "📕", "微博": "📢", "支付宝": "💙",
    "淘宝": "🛒", "京东": "🐶", "美团": "🛵", "饿了么": "🍔", "拼多多": "📦",
    "快手": "📹", "B站": "📺", "哔哩哔哩": "📺", "知乎": "🧠", "芒果TV": "🥭",
    "百度": "🔍", "网易云音乐": "🎧", "高德地图": "🗺", "滴滴": "🚗",
    "携程旅行": "🐬", "携程": "🐬", "大众点评": "⭐", "闲鱼": "🐟", "得物": "👟",
}

_STATIC_ICONS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "icons")


def _esc(s):
    return html.escape(str(s or ""))


def _render_text(s):
    """转义后把 **文字** 转成高亮 span(镜像前端 renderText)。"""
    escaped = html.escape(str(s or ""))
    return re.sub(r"\*\*(.+?)\*\*", r'<span class="hl">\1</span>', escaped)


def _icon_data_uri(app):
    fname = APP_ICON_FILES.get(app)
    if not fname:
        return None
    path = os.path.join(_STATIC_ICONS, fname)
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f"data:image/png;base64,{b64}"


def _app_icon_html(app):
    uri = _icon_data_uri(app)
    if uri:
        return f'<img class="app-icon-img" src="{uri}" alt="{_esc(app)}">'
    emoji = APP_EMOJI.get(app)
    return f'<span class="app-icon">{emoji}</span>' if emoji else ""


def _find_file(sid):
    for root, _, files in os.walk(SCREENSHOTS_DIR):
        for f in files:
            if os.path.splitext(f)[0] == sid:
                return os.path.join(root, f)
    return None


def _thumb_data_uri(path):
    """读取截图,缩放为 JPEG 后 base64,控制体积。失败返回 None。"""
    try:
        img = Image.open(path)
        if img.mode in ("RGBA", "P", "LA"):
            img = img.convert("RGB")
        w, h = img.size
        if w > THUMB_WIDTH:
            img = img.resize((THUMB_WIDTH, int(h * THUMB_WIDTH / w)), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=THUMB_QUALITY, optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode()
        return f"data:image/jpeg;base64,{b64}"
    except Exception as e:
        print(f"  ⚠ 缩略图编码失败 {path}: {e}")
        return None


def _build_comparison_board(proj, sid_to_meta):
    """模块 × App 对比看板。sid_to_meta[sid] = {app, data_uri}。"""
    a = proj.get("analysis") or {}
    tags = a.get("screenshot_tags") or {}
    if not tags:
        return ""

    # 文件名(带扩展名) → sid
    filename_to_sid = {}
    for sid in proj.get("screenshots", {}):
        meta = sid_to_meta.get(sid)
        if meta:
            filename_to_sid[sid + meta["ext"]] = sid

    # touchpointApps[模块][app] = [sid, ...]
    touchpoint_apps = {}
    app_counts = {}
    for filename, tp in tags.items():
        sid = filename_to_sid.get(filename) or re.sub(r"\.\w+$", "", filename)
        meta = sid_to_meta.get(sid)
        if not meta:
            continue
        app = meta["app"] or "未归类"
        touchpoint_apps.setdefault(tp, {}).setdefault(app, []).append(sid)
        app_counts[app] = app_counts.get(app, 0) + 1

    if not touchpoint_apps:
        return ""

    touchpoints = sorted(
        touchpoint_apps,
        key=lambda t: sum(len(v) for v in touchpoint_apps[t].values()),
        reverse=True,
    )
    pinned = ["京东"]
    app_names = sorted(app_counts, key=lambda x: app_counts[x], reverse=True)
    apps = [a for a in pinned if a in app_names] + [a for a in app_names if a not in pinned]

    tp_analysis = {t.get("touchpoint"): t for t in (a.get("touchpoint_analysis") or [])}

    cols = f"140px repeat({len(apps)}, 150px)"
    out = [f'<div class="cmp-table" style="grid-template-columns:{cols};">']
    out.append('<div class="cmp-hd-corner">模块</div>')
    for app in apps:
        out.append(f'<div class="cmp-hd-app">{_app_icon_html(app)}{_esc(app)}</div>')

    for tp in touchpoints:
        out.append(f'<div class="cmp-row-tp">{_esc(tp)}</div>')
        for app in apps:
            sids = touchpoint_apps[tp].get(app, [])
            if sids:
                imgs = "".join(
                    f'<img class="cmp-thumb" src="{sid_to_meta[s]["data_uri"]}" alt="{_esc(app)}">'
                    for s in sids if sid_to_meta.get(s, {}).get("data_uri")
                )
                out.append(f'<div class="cmp-cell">{imgs}</div>')
            else:
                out.append('<div class="cmp-cell"><span class="cmp-empty">—</span></div>')

        analysis = tp_analysis.get(tp)
        if analysis:
            parts = [f'<strong>对比分析：</strong>{_render_text(analysis.get("comparison"))}']
            hls = analysis.get("highlights") or []
            if hls:
                parts.append(
                    '<div class="cmp-sub"><strong>亮点：</strong>'
                    + "；".join(_render_text(h) for h in hls) + "</div>"
                )
            if analysis.get("best_practice"):
                parts.append(
                    '<div class="cmp-sub"><strong>最佳实践：</strong>'
                    + _render_text(analysis["best_practice"]) + "</div>"
                )
            out.append(f'<div class="cmp-analysis-row">{"".join(parts)}</div>')

    out.append("</div>")
    return f'<section class="section"><h2 class="section-title">📊 竞品对比看板</h2><div class="cmp-scroll">{"".join(out)}</div></section>'


def _build_analysis(a):
    out = []

    if a.get("overview") or a.get("recommendations"):
        out.append('<section class="section"><h2 class="section-title">💡 设计策略总结</h2>')
        if a.get("overview"):
            out.append(f'<p class="overview">{_render_text(a["overview"])}</p>')
        if a.get("recommendations"):
            out.append(f'<div class="recommend">{_render_text(a["recommendations"])}</div>')
        out.append("</section>")

    pc = a.get("platform_comparison") or []
    if pc:
        out.append('<section class="section"><h2 class="section-title">📱 平台设计特点</h2><div class="platform-grid">')
        for p in pc:
            tags_html = "".join(
                f'<span class="tag tag-good">✓ {_render_text(s)}</span>' for s in (p.get("strengths") or [])
            ) + "".join(
                f'<span class="tag tag-bad">✗ {_render_text(w)}</span>' for w in (p.get("weaknesses") or [])
            )
            desc = f'<p class="platform-desc">{_render_text(p.get("characteristics"))}</p>' if p.get("characteristics") else ""
            out.append(
                f'<div class="platform-item"><div class="platform-head">'
                f'<span class="platform-icon">{_app_icon_html(p.get("platform"))}</span>'
                f'<span class="platform-name">{_esc(p.get("platform"))}</span></div>'
                f'{desc}<div class="platform-tags">{tags_html}</div></div>'
            )
        out.append("</div></section>")

    dh = a.get("design_highlights") or []
    if dh:
        out.append('<section class="section"><h2 class="section-title">🔍 设计亮点</h2><ul class="highlights">')
        for d in dh:
            reason = f'<span class="hl-reason">{_render_text(d.get("why_good"))}</span>' if d.get("why_good") else ""
            out.append(
                f'<li><span class="hl-desc">{_render_text(d.get("description"))}</span> '
                f'<span class="hl-platform">{_app_icon_html(d.get("platform"))}{_esc(d.get("platform"))}</span>{reason}</li>'
            )
        out.append("</ul></section>")

    return "".join(out)


_CSS = """
* { box-sizing: border-box; }
body { margin: 0; font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
  color: #1a1a1a; background: #f4f4f5; line-height: 1.6; }
.wrap { max-width: 1100px; margin: 0 auto; padding: 32px 24px 64px; }
.report-head { margin-bottom: 8px; }
.report-title { font-size: 26px; font-weight: 700; margin: 0 0 6px; }
.report-desc { color: #666; font-size: 14px; margin: 0; }
.report-meta { color: #999; font-size: 12px; margin-top: 10px; }
.section { background: #fff; border-radius: 12px; padding: 20px 24px; margin-top: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
.section-title { font-size: 16px; font-weight: 600; margin: 0 0 16px; }
.app-icon-img { width: 18px; height: 18px; border-radius: 4px; vertical-align: -3px; margin-right: 4px; }
.app-icon { margin-right: 4px; }
.hl { font-weight: 600; text-decoration: underline; text-decoration-color: rgba(0,0,0,0.2);
  text-underline-offset: 2px; text-decoration-thickness: 2px; }
.overview { font-size: 14px; color: #555; margin: 0 0 12px; }
.recommend { font-size: 14px; color: #555; background: #f9f9f9; border-radius: 8px;
  padding: 14px 16px; border-left: 3px solid #2d7234; }
.platform-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 12px; }
.platform-item { background: #f9f9f9; border-radius: 8px; padding: 14px; }
.platform-head { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.platform-name { font-weight: 600; }
.platform-desc { font-size: 13px; color: #666; margin: 0 0 10px; }
.platform-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.tag { font-size: 12px; padding: 3px 8px; border-radius: 6px; background: #eee; color: #444; }
.tag-good { background: #eaf5ec; color: #2d7234; }
.tag-bad { background: #fbeaea; color: #b84040; }
.highlights { margin: 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 12px; }
.highlights li { font-size: 14px; padding: 12px 14px; background: #f9f9f9; border-radius: 8px; }
.hl-desc { color: #333; }
.hl-platform { display: inline-flex; align-items: center; font-size: 12px; color: #888; margin: 0 6px; white-space: nowrap; }
.hl-reason { display: block; font-size: 13px; color: #777; margin-top: 4px; }
.cmp-scroll { overflow-x: auto; }
.cmp-table { display: grid; gap: 1px; background: #e5e5e5; border: 1px solid #e5e5e5; border-radius: 8px; overflow: hidden; min-width: 640px; }
.cmp-hd-corner, .cmp-hd-app { background: #fafafa; font-weight: 600; font-size: 13px; padding: 10px 8px; display: flex; align-items: center; justify-content: center; text-align: center; }
.cmp-hd-app { gap: 4px; }
.cmp-row-tp { background: #fafafa; font-weight: 600; font-size: 13px; padding: 10px 8px; display: flex; align-items: center; }
.cmp-cell { background: #fff; padding: 6px; display: flex; flex-wrap: wrap; gap: 4px; align-content: flex-start; }
.cmp-thumb { width: 56px; height: 120px; object-fit: cover; border-radius: 4px; border: 1px solid #eee; cursor: zoom-in; }
.cmp-empty { color: #ccc; margin: auto; }
.cmp-analysis-row { grid-column: 1 / -1; background: #fffdf5; font-size: 13px; color: #555; padding: 12px 14px; border-top: 1px dashed #e5d9b0; }
.cmp-sub { margin-top: 4px; }
.footer { text-align: center; color: #bbb; font-size: 12px; margin-top: 32px; }
/* 点击缩略图放大 */
.lb { position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: none; align-items: center; justify-content: center; z-index: 999; cursor: zoom-out; }
.lb.open { display: flex; }
.lb img { max-width: 92vw; max-height: 92vh; border-radius: 6px; }
@media print { body { background: #fff; } .section { box-shadow: none; border: 1px solid #eee; } }
"""

_LIGHTBOX_JS = """
document.addEventListener('click', function(e){
  if (e.target.classList.contains('cmp-thumb')) {
    var lb = document.getElementById('lb');
    document.getElementById('lbImg').src = e.target.src;
    lb.classList.add('open');
  } else if (e.target.id === 'lb' || e.target.id === 'lbImg') {
    document.getElementById('lb').classList.remove('open');
  }
});
"""


def export_project_html(proj, generated_at=""):
    """proj: 单个项目 dict(含 analysis、screenshots)。返回完整 HTML 字符串。"""
    a = proj.get("analysis") or {}

    # 预处理:sid → {app, ext, data_uri}
    sid_to_meta = {}
    for sid in proj.get("screenshots", {}):
        path = _find_file(sid)
        if not path:
            continue
        rel = os.path.relpath(path, SCREENSHOTS_DIR)
        parts = rel.split(os.sep)
        app = parts[0] if len(parts) >= 2 else None
        sid_to_meta[sid] = {
            "app": app,
            "ext": os.path.splitext(path)[1],
            "data_uri": _thumb_data_uri(path),
        }

    board = _build_comparison_board(proj, sid_to_meta)
    analysis_html = _build_analysis(a)

    name = _esc(proj.get("name"))
    desc = f'<p class="report-desc">{_esc(proj.get("description"))}</p>' if proj.get("description") else ""
    meta = f'<div class="report-meta">共 {len(sid_to_meta)} 张截图 · 由 DesignPeek 生成'
    meta += f' · {_esc(generated_at)}</div>' if generated_at else "</div>"

    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{name} · 竞品分析报告</title>
<style>{_CSS}</style>
</head><body>
<div class="wrap">
  <div class="report-head">
    <h1 class="report-title">{name}</h1>
    {desc}
    {meta}
  </div>
  {analysis_html}
  {board}
  <div class="footer">DesignPeek 设计透视 · 本报告为离线快照，截图已内嵌，可直接分享</div>
</div>
<div class="lb" id="lb"><img id="lbImg" src="" alt=""></div>
<script>{_LIGHTBOX_JS}</script>
</body></html>"""
